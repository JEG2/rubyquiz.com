class NameFile

  def initialize(file)
    case file
    when IO
      @names = file.to_a
    when String
      @names = File.open(file) { |f| f.to_a }
    else
      fail "Need IO or filename"
    end
  end

  def pick_name
    @names.delete_at(rand(@names.size))
  end

  def save(file)
    File.open(file, 'w') { |f| f.puts @names.join }
  end

  def size
    @names.size
  end

end

