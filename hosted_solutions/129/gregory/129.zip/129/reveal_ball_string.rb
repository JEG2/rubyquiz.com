require 'render_layer'
require 'letter_ball'
require 'interpolate'
require 'rotate_anim'
require 'scale_anim'

class RevealBallString
  include Renderable

  module SimpleUTF8
    def to_char_array
      scan /[\000-\177]|[\300-\337][\200-\277]|[\340-\357][\200-\277]{2}|[\360-\367][\200-\277]{3}/
    end
  end

  def initialize(str = 'Reveal', delay = 0.2)
    @delay = delay
    @string_rows = string_to_rows(str)
    @color = [ 1, 1, 1 ]
    @halign = @valign = :center
  end

  private

  def display(*args)
    font = self.class::Font
    Gl.glPushMatrix
    case halign
    when :center
      Gl.glTranslatef(-width*0.5, 0, 0)
    when :right
      Gl.glTranslatef(-width, 0, 0)
    end
    case valign
    when :center
      Gl.glTranslatef(0, -height*0.25, 0)
    when :top
      Gl.glTranslatef(0, -height, 0)
    end
    Gl.glColor3f(*color)
    Gl.glScale(@scale, @scale, 1)
    @string.each_byte { |c| Glut.glutStrokeCharacter(font, c) }
    Gl.glPopMatrix
  end

  def display(seconds)
    unless @ball_rows
      textures = gen_missing_textures
      delay = @delay
      @ball_rows = @string_rows.map { |w|
        w.map { |c| build_ball(c, textures, (delay += 0.1)) }
      }
    end
    Gl.glPushMatrix
    Gl.glTranslatef(0, 1.5*(@ball_rows.size-1), 0)
    @ball_rows.each { |row|
      Gl.glPushMatrix
      Gl.glTranslatef((1-row.size), 0, 0)
      row.each { |ball|
        ball.first.get_display.call(seconds)
        Gl.glTranslatef(2, 0, 0)
      }
      Gl.glPopMatrix
      Gl.glTranslatef(0, -3, 0)
    }
    Gl.glPopMatrix
  end

  def string_to_rows(str)
    #TODO: this should be smarter, but isn't
    words = str.split(/\s+/).map { |w| w.extend(SimpleUTF8).to_char_array }
  end

  def gen_missing_textures
    count = (@string_rows.flatten - ball_cache.keys).size
    Gl.glGenTextures(count)
  end

  class Noop
    include Renderable

    NoopProc = lambda { |*args| nil }

    def get_display
      NoopProc
    end

  end

  def self.ball_cache
    @ball_cache ||= { ' ' => Noop.new }
  end

  def ball_cache
    self.class.ball_cache
  end

  def build_ball(char, textures, delay)
    spin = RotateAnim.new(1, 0, 0)
    spin_interp = Interpolator.new(0.6, true)
    spin.compose_effect spin_interp
    ball = (ball_cache[char] ||= LetterBall.new(char, textures.pop)).get_display
    spin.add_display { |t|
      Gl.glScalef(0.01, 0.01, 0.01)
      ball.call(t)
    }
    scale = ScaleAnim.new(100, 100, 100)
    scale_interp = Interpolator.new(1.0, false, false)
    scale.compose_effect scale_interp
    spin.setup(scale)
    scale_interp.start_in delay
    spin_interp.start_in delay, 2
    [ scale, scale_interp, spin_interp ]
  end

end

