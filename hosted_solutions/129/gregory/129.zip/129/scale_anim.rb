require 'render_layer'

class ScaleAnim
  include Renderer

  def initialize(x, y, z)
    @scale = [ x, y, z ]
  end

  def wrap_display(block)
    lambda { |seconds|
      return unless t = effect_interp(seconds)
      return unless seconds = interpolate(seconds)
      Gl.glPushMatrix
      Gl.glScalef(*@scale.map{ |v| v*t })
      block.call(seconds)
      Gl.glPopMatrix
    }
  end

end

