require 'rubygems'
require 'gl'
require 'glu'
require 'glut'

module Renderable

  def setup(main)
    main.add_display_proc get_display
  end

  def get_display
    @display_proc ||= method(:display).to_proc
  end

end

module Renderer

  def setup(main)
    main.add_display_proc get_display
  end

  def add_display(&renderer)
    (@renderers ||= []) << renderer
  end

  def add_display_proc(renderer)
    fail "Expected Proc" unless Proc === renderer
    (@renderers ||= []) << renderer
  end

  def get_display
    @display_proc ||= wrap_display method(:render_all).to_proc
  end

  def compose_effect(func)
    @effect_interp = compose_func(func, @effect_interp)
  end

  def compose_interp(func)
    @interpolator = compose_func(func, @interpolator)
  end

  private

  def compose_func(f, g)
    g ? lambda { |t| f[g[t]] } : f
  end

  def render_all(seconds)
    (@renderers ||= []).each { |r| r.call(seconds) rescue nil }
  end

  # wrap_display lambda should call interpolate
  def interpolate(time)
    @interpolator ? @interpolator[time] : time
  end

  # wrap_display lambda should possibly call effect_interp
  def effect_interp(time)
    @effect_interp ? @effect_interp[time] : time
  end

  def display(seconds)
    get_display.call(seconds)
  end

end

class GlutMain
  include Renderer

  def initialize(window_name, ortho = false)
    @keyhandlers = []
    @ortho = ortho
    Glut.glutInit
    Glut.glutInitDisplayMode( Glut::GLUT_DOUBLE | Glut::GLUT_RGB | Glut::GLUT_DEPTH )
    Glut.glutCreateWindow(window_name || 'GLUT')
  end

  def start
    self.class.instance_variable_set('@started', Time.now)
    Glut.glutDisplayFunc method(:display).to_proc
    Glut.glutReshapeFunc method(:reshape).to_proc
    Glut.glutIdleFunc Glut.method(:glutPostRedisplay).to_proc
    Glut.glutKeyboardFunc method(:handle_key).to_proc
    Gl.glShadeModel(Gl::GL_SMOOTH)
    Gl.glPolygonMode(Gl::GL_FRONT, Gl::GL_FILL | Gl::GL_LINE)
    Gl.glEnable(Gl::GL_CULL_FACE)
    Gl.glEnable(Gl::GL_DEPTH_TEST)
    Gl.glEnable(Gl::GL_ALPHA_TEST)
    Gl.glEnable(Gl::GL_BLEND)
    Gl.glEnable(Gl::GL_LINE_SMOOTH)
    Gl.glHint(Gl::GL_LINE_SMOOTH_HINT, Gl::GL_NICEST)
    Gl.glEnable(Gl::GL_POLYGON_SMOOTH)
    Gl.glHint(Gl::GL_POLYGON_SMOOTH_HINT, Gl::GL_NICEST)
    yield if block_given?
    Glut.glutMainLoop
  end

  def add_keyhandler(key, &action)
    @keyhandlers << [ key, action ]
  end

  def self.time
    @started ? (Time.now - @started) : 0.0
  end

  private

  def display
    Gl.glClear( Gl::GL_COLOR_BUFFER_BIT | Gl::GL_DEPTH_BUFFER_BIT )
    Gl.glMatrixMode(Gl::GL_MODELVIEW)
    render_all(GlutMain.time)
    Gl.glFlush
    Glut.glutSwapBuffers
  end

  def handle_key(key, x, y)
    waste,action = @keyhandlers.find { |k,a| k === key }
    action.call if action
  end

  def reshape(w, h)
    x,y = (w>h) ? [ h/w.to_f, 1 ] : [ 1, w/h.to_f ]
    Gl.glViewport(0, 0, w, h)
    Gl.glMatrixMode(Gl::GL_PROJECTION)
    Gl.glLoadIdentity
    if @ortho
      Gl.glOrtho(-y, y, -x, x, 1000, -1000)
    else
      GLU.gluPerspective(75, w/h.to_f, 1, 10000)
      GLU.gluLookAt(0.0, 0.0, 7.0,
                    0.0, 0.0, 0.0,
                    0.0, 1.0, 0.0)
    end
    Gl.glMatrixMode(Gl::GL_MODELVIEW)
  end

end

