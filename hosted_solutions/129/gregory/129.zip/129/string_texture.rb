require 'magick_texture'

class StringTexture < MagickTexture

  def initialize(width_, height_, str)
    super(width_, height_)
    draw_text(str)
  end

  PIXEL_TYPE = Gl::GL_UNSIGNED_BYTE
  PIXEL_INTERNAL_FORMAT = Gl::GL_LUMINANCE
  PIXEL_FORMAT = Gl::GL_LUMINANCE

  def set_as_texture(texture = nil)
    texture = texture_gl_prep(texture)
    GLU.gluBuild2DMipmaps(Gl::GL_TEXTURE_2D, PIXEL_INTERNAL_FORMAT,
                          width, height, PIXEL_FORMAT, PIXEL_TYPE,
                          export_gray);
    texture
  end
end
