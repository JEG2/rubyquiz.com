require 'render_layer'
require 'string_texture'

class LetterBall
  include Renderable
  attr_accessor :color

  def initialize(letter, texture_name = nil)
    @img = StringTexture.new(128, 128, letter)
    @texture_name = texture_name
  end

  TWOPI = Math::PI * 2
  PID2 = Math::PI / 2

  def self.display
    if @display_list
      Gl.glCallList(@display_list)
    else
      n = 128
      r = 1
      @display_list = Gl.glGenLists(1)
      Gl.glNewList(@display_list, Gl::GL_COMPILE_AND_EXECUTE)
      Gl.glEnable(Gl::GL_TEXTURE_2D)
      Gl.glDisable(Gl::GL_TEXTURE_GEN_S)
      Gl.glDisable(Gl::GL_TEXTURE_GEN_T)
      @img = nil
      Gl.glColor3f(1, 1, 1)

      (n/2).times { |j|
        theta1 = j * TWOPI / n - PID2
        theta2 = (j + 1) * TWOPI / n - PID2

        Gl.glBegin(Gl::GL_QUAD_STRIP)

        (0..n).each { |i|
          theta3 = i * TWOPI / n

          ex = Math.cos(theta2) * Math.cos(theta3)
          ey = Math.sin(theta2)
          ez = Math.cos(theta2) * Math.sin(theta3)
          px = r * ex
          py = r * ey
          pz = r * ez

          Gl.glNormal3f(ex,ey,ez)
          s = 2*i/n.to_f
          t = 2*(j+1)/n.to_f
          if s > 1
            t = 1-t
          else
            s = 2-s
          end
          Gl.glTexCoord2f(s, t)
          Gl.glVertex3f(px,py,pz)

          ex = Math.cos(theta1) * Math.cos(theta3)
          ey = Math.sin(theta1)
          ez = Math.cos(theta1) * Math.sin(theta3)
          px = r * ex
          py = r * ey
          pz = r * ez

          Gl.glNormal3f(ex,ey,ez)
          s = 2*i/n.to_f
          t = 2*(j+1)/n.to_f
          if s > 1
            t = 1-t
          else
            s = 2-s
          end
          Gl.glTexCoord2f(s, t)
          Gl.glVertex3f(px,py,pz)
        }
        Gl.glEnd
      }
      Gl.glDisable(Gl::GL_TEXTURE_2D)
      Gl.glEndList
    end
  end

  private

  def texture_name
    if @img
      @texture_name = @img.set_as_texture(@texture_name)
      @img = nil
    end
    @texture_name
  end

  def display(*args)
    Gl.glBindTexture(Gl::GL_TEXTURE_2D, texture_name)
    self.class.display
  end

end

