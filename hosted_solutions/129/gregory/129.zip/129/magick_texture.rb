require 'rubygems'
require 'gl'
require 'glu'
require 'rmagick'

class MagickTexture
  include Magick
  attr_reader :image

  def initialize(width_, height_)
    @image = Image.new(width_, height_) {
      self.background_color = 'white'
    }
    @image.set_channel_depth(AllChannels, 8)
  end

  def draw_text(text, &block)
    draw_obj.annotate(@image, width, height, 0, 0, text, &block)
  end

  def draw
    result = yield draw_obj, @image
    draw_obj.draw(@image) rescue nil
    result
  end

  def export_rgba
    @image.export_pixels_to_str(0, 0, width, height,
                                "RGBA", IntegerPixel)
  end

  def export_gray
    @image.export_pixels_to_str(0, 0, width, height,
                                "I", CharPixel)
  end

  PIXEL_TYPE = Gl::GL_UNSIGNED_INT
  #PIXEL_TYPE = Gl::GL_UNSIGNED_BYTE
  PIXEL_INTERNAL_FORMAT = Gl::GL_RGBA
  PIXEL_FORMAT = Gl::GL_RGBA

  def set_as_texture(texture = nil)
    texture = texture_gl_prep(texture)
    GLU.gluBuild2DMipmaps(Gl::GL_TEXTURE_2D, PIXEL_INTERNAL_FORMAT,
                          width, height, PIXEL_FORMAT, PIXEL_TYPE,
                          export_rgba);
    texture
  end

  def width
    @image.columns
  end

  def height
    @image.rows
  end

  private

  def texture_gl_prep(texture = nil)
    texture ||= Gl.glGenTextures(1)[0]
    Gl.glBindTexture(Gl::GL_TEXTURE_2D, texture)
    Gl.glPixelStorei(Gl::GL_UNPACK_ALIGNMENT, 1);
    Gl.glTexParameterf(Gl::GL_TEXTURE_2D, Gl::GL_TEXTURE_WRAP_S,
                       Gl::GL_REPEAT)
    Gl.glTexParameterf(Gl::GL_TEXTURE_2D, Gl::GL_TEXTURE_WRAP_T,
                       Gl::GL_REPEAT)
    Gl.glTexParameterf(Gl::GL_TEXTURE_2D, Gl::GL_TEXTURE_MIN_FILTER,
                       Gl::GL_LINEAR_MIPMAP_NEAREST)
    Gl.glTexParameterf(Gl::GL_TEXTURE_2D, Gl::GL_TEXTURE_MAG_FILTER,
                       Gl::GL_LINEAR)
    texture
  end

  def draw_obj
    # these are defaults, but can be overridden in draw_text
    @draw ||= Draw.new {
      self.encoding = 'UTF-8'
      self.gravity = CenterGravity
      self.pointsize = 90
      self.font_family = 'arial'
      self.font_weight = 600
      self.text_antialias = true
      self.stroke = 'transparent'
    }
  end

end

if $PROGRAM_NAME == __FILE__
  img = MagickTexture.new(128, 128)
  img.draw_text "A"
  img.image.display
end
