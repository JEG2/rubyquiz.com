require 'render_layer'

class RotateAnim
  include Renderer

  def initialize(x, y, z)
    norm = 1/Math.sqrt(x**2 + y**2 + z**2)
    x *= norm
    y *= norm
    z *= norm
    @vector = [ x, y, z ]
  end

  FULL_ROTATION = 360.0

  def wrap_display(block)
    lambda { |seconds|
      return unless t = effect_interp(seconds)
      return unless seconds = interpolate(seconds)
      Gl.glPushMatrix
      Gl.glRotatef(t*FULL_ROTATION, *@vector)
      block.call(seconds)
      Gl.glPopMatrix
    }
  end

  private

  def display(seconds)
    get_display.call(seconds)
  end

end

