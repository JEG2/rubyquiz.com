require 'render_layer'

class RenderText
  include Renderable
  attr_accessor :halign, :valign, :color

  def initialize(str = 'GLUT', scale = 0.01)
    @string = str
    @scale = scale
    @color = [ 1, 1, 1 ]
    @halign = @valign = :center
  end

  def width
    @width ||= @scale * self.class.width(@string)
  end

  def height
    @height ||= @scale * self.class.height(@string)
  end

  def string=(val)
    @string = val.to_s
    @width = nil
  end

  def self.new(*args)
    fail "Abstract class" if self == ::RenderText
    super(*args)
  end

  def self.width(str)
    size = 0
    font = self::Font
    str.each_byte { |c| size += Glut.glutStrokeWidth(font, c) }
    size
  end

  def self.height(str)
    Glut.glutStrokeLength(self::Font, str)
  end

  def display(*args)
    font = self.class::Font
    Gl.glPushMatrix
    case halign
    when :center
      Gl.glTranslatef(-width*0.5, 0, 0)
    when :right
      Gl.glTranslatef(-width, 0, 0)
    end
    case valign
    when :center
      Gl.glTranslatef(0, -height*0.25, 0)
    when :top
      Gl.glTranslatef(0, -height, 0)
    end
    Gl.glColor3f(*color)
    Gl.glScale(@scale, @scale, 1)
    @string.each_byte { |c| Glut.glutStrokeCharacter(font, c) }
    Gl.glPopMatrix
  end

end

class RenderText::Roman < RenderText
  Font = Glut::GLUT_STROKE_ROMAN
end

class RenderText::Mono < RenderText
  Font = Glut::GLUT_STROKE_MONO_ROMAN
end

