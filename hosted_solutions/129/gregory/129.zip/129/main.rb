unless ARGV.size == 1 && File.exist?(ARGV[0])
  STDERR.puts "Usage: #{$PROGRAM_NAME} <namelist>"
  exit 1
end

require 'render_layer'
require 'lone_star'
require 'reveal_ball_string'
require 'name_file'

class Picker
  include Renderable

  def initialize(file)
    @names = NameFile.new(file)
    @lonestar = LoneStar.new(2.5).get_display
  end

  def pick_name
    @name_display = @name_display ? nil :
      RevealBallString.new(@names.pick_name, 0.1).get_display
  end

  def save(filename)
    @names.save(filename)
  end

  private

  def display(seconds)
    (@name_display || @lonestar).call(seconds)
  end

end

picker = Picker.new(ARGV[0])

gt = GlutMain.new('testing', true)

gt.add_display {
  Gl.glPushMatrix
  Gl.glScalef(0.125, 0.125, 0.125)
}
gt.add_display_proc picker.get_display
gt.add_display { Gl.glPopMatrix }

gt.add_keyhandler(27) { picker.save ARGV[0]; exit 0 } #ESC
gt.add_keyhandler(32) { picker.pick_name }            #space
gt.add_keyhandler(18) { picker.save ARGV[0] }         #ctrl-s
gt.start

