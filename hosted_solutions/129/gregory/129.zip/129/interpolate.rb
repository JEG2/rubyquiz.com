require 'render_layer'

class Interpolator
  attr_accessor :period

  def initialize(seconds = 1.0, repeat = false, autostart = true, &param_func)
    @period = seconds
    @repeat = repeat
    unless autostart
      @alpha = 0.0
      @stopped = @period
    end
    @param_func = param_func
  end

  def restart(repeat = false)
    @repeat = repeat
    @alpha = nil
  end

  def start_over(repeat = false)
    @stopped = nil
    restart(repeat)
  end

  def start_at(seconds, repeat = false)
    start_over(repeat)
    @alpha = seconds
  end

  def start_in(seconds, repeat = false)
    start_at(GlutMain.time + seconds, repeat)
  end

  def stop(finish_period = false)
    unless @stopped
      if finish_period
        @repeat = false
      else
        @stopped = true
      end
    end
  end

  def call(seconds)
    unless @alpha
      @alpha = seconds
      if @stopped
        @alpha -= @stopped if @stopped != true
        @stopped = nil
      end
    end
    seconds -= @alpha
    # escape out if on a delay
    return nil if seconds < 0.0
    case @stopped
    when TrueClass
      @stopped = seconds
    when NilClass
      while seconds > @period && @repeat
        @alpha += @period
        seconds -= @period
        if Integer === @repeat
          @repeat -= 1
          @repeat = false if @repeat <= 0
        end
      end
      # stop and clamp if necessary
      if seconds > @period
        seconds = @period
        @stopped = @period
      end
    else
      seconds = @stopped
    end
    seconds /= @period
    seconds
  end

  alias [] call

  private

  def display(seconds)
    get_display.call(seconds)
  end

end

class Interpolate
  include Renderer

  def initialize(seconds = 1.0, repeat = false, autostart = true)
    @interp = Interpolator.new(seconds, repeat, autostart)
    compose_interp @interp
  end

  def wrap_display(block)
    lambda { |time| block.call interpolate(time) }
  end

  def restart(repeat = false)
    @interp.restart repeat
  end

  def start_over(repeat = false)
    @interp.start_over repeat
  end

  def start_at(seconds, repeat = false)
    @interp.start_at seconds, repeat
  end

  def start_in(seconds, repeat = false)
    @interp.start_in seconds, repeat
  end

  def stop(finish_period = false)
    @interp.stop finish_period
  end

end

