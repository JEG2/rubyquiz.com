require 'interpolate'
require 'rotate_anim'
require 'render_text'

class LoneStar
  include Renderable

  WORDS = %w{Lone Star Ruby Conf}

  def initialize(period)
    @period = period
  end

  private

  def display(seconds)
    p = displays
    Gl.glPushMatrix
    Gl.glTranslatef(-4*@char_width, @char_height, 0)
    p[0][seconds]
    Gl.glTranslatef(@char_width, 0, 0)
    p[1][seconds]
    Gl.glPopMatrix
    Gl.glPushMatrix
    Gl.glTranslatef(-4*@char_width, -@char_height, 0)
    p[2][seconds]
    Gl.glTranslatef(@char_width, 0, 0)
    p[3][seconds]
    Gl.glPopMatrix
  end

  def displays
    @displays ||= WORDS.map { |w| build_word w }
  end

  def build_word(word)
    color = [ 0, 1, 0 ]
    interp = Interpolator.new(@period, true)
    procs = word.scan(/./).map { |c|
      theta = rand * Math::PI / 2 + Math::PI / 4
      rot = RotateAnim.new(Math.cos(theta), Math.sin(theta), 0)
      rot.compose_effect(interp)
      char = RenderText::Mono.new(c)
      char.color = color
      @char_width ||= char.width
      @char_height ||= char.height
      rot.wrap_display(char.get_display)
    }
    lambda { |seconds|
      procs.each { |p|
        p.call(seconds)
        Gl.glTranslatef(@char_width, 0, 0)
      }
    }
  end

end
