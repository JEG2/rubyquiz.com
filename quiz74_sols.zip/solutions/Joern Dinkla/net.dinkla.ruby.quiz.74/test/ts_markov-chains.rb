#

$:.unshift File.join(File.dirname(__FILE__), "..", "lib")

require 'test/unit'
require 'tc_words'
require 'tc_markov-chain'
require 'tc_story-generator'

