# * Shuffle the contents of a provided Array.
#
#...+....|....+....2....+....|....+....|....+....5....+....|....+....|....+....8
quiz.sort_by{ rand }
