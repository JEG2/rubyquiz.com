# Provided with an open File object, select a random line of content.
#...+....|....+....2....+....|....+....|....+....5....+....|....+....|....+....8
q=quiz.readlines; q[ rand( q.size ) ].chomp
