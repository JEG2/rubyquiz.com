quiz.inject([]){|r,a|r+[*a]}
r=[];quiz.each{|a|r+=[*a]};r
