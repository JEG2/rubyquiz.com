#!/usr/local/bin/ruby -w

# ts_all.rb
#
#  Created by James Edward Gray II on 2005-06-13.
#  Copyright 2005 Gray Productions. All rights reserved.

require "test/unit"

require "tc_board"
require "tc_pawn"
require "tc_knight"
require "tc_rook"
require "tc_bishop"
require "tc_queen"
require "tc_king"
