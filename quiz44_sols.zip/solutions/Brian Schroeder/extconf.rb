require 'mkmf'
create_makefile("priority_queue")
