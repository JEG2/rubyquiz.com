require 'mkmf'

create_makefile('horndude_generator')

