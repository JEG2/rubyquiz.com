require 'tests/csp-variable-tests'
require 'tests/csp-constraint-tests'
require 'tests/csp-problem-tests'
require 'tests/csp-backtracking-tests'
