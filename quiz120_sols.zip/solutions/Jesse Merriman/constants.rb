#!/usr/bin/env ruby
# constants.rb
# Ruby Quiz 120: Magic Fingers

Left,    Right   = 0, 1 # hand array indices
Player1, Player2 = 0, 1 # player array indices
FingersPerHand   = 5    # on my machine, > 6 causes a stack overflow
