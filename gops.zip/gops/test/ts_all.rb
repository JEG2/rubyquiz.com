#!/usr/bin/env ruby -w

require "test/unit"

require "tc_player"
require "tc_game"

require "tc_illegal_bot"
require "tc_random_bot"
require "tc_ordered_bot"
require "tc_mimic_bot"
