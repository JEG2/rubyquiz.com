#!/usr/bin/env ruby -w

$stdin.gets    # competition card--ignored
$stdout.puts 0 # illegal card
