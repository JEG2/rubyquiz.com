1.upto(?d){|n|puts n%15<1?:FizzBuzz:n%3<1?:Fizz:n%5<1?:Buzz:n}
