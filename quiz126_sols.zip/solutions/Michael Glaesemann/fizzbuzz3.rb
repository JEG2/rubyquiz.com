# golf solution (70 chars)
1.upto(?d){|n|puts 0<n%3&&0<n%5?n:(1>n%3?"Fizz":'')+(1>n%5?"Buzz":'')}
