d=IO.read$*[0];puts d[54..-1].scan(/.../m).map{|s|"DY8S65Jjtc+i!;:."[s.unpack(
"CCC").inject{|a,b|a+b}/48,1]}.join.scan(/.{#{d[18,4].unpack"V"}}/).reverse
