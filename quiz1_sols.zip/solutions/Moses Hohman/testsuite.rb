#!/usr/bin/env ruby
require 'test/unit'
require 'test_cipher'
require 'test_deck'
require 'test_util'
