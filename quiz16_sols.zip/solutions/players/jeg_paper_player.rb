#!/usr/biin/env ruby

class JEGPaperPlayer < Player
	def choose
		:paper
	end
end
