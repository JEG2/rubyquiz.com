class DisplayListener

  def start_game(io)
  end

  def end_game
    puts "Game over!"
  end

  def move(piece, from, to)
  end

  def capture(attacker, loser)
  end

  def check
    puts "Check!"
  end

  def checkmate
    puts "Checkmate!"
  end

  def pawn_to_queen(pawn)
  end

end
